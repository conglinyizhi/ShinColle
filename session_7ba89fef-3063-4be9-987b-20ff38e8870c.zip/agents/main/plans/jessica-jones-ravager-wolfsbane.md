# 编译错误修复计划

## 当前状态

- **已修复/重写文件数**：约 150+ 个文件
- **剩余编译错误**：约 2288 个（最初约 4183 个）
- **关键进展**：
  - JEI 集成（9 个文件）已完全重写，错误清零
  - Jade 集成（3 个文件）已完全重写，错误清零
  - Cloth Config 配置屏幕（`ShincolleConfigScreen.kt`）已完全重写，错误清零
  - 客户端事件注册（`ClientModEventBusEvents.kt`）已重写结构，剩余 76 个错误均为依赖文件未编译通过导致的引用错误

## 错误分布（Top 50）

| 文件 | 错误数 | 说明 |
|------|--------|------|
| EntityShipBrainAi.kt | 105 | AI Behavior 系统 |
| ClientModEventBusEvents.kt | 76 | 客户端事件注册 |
| EntityShipBaseCombat.kt | 67 | 舰船战斗基类 |
| EntityShipBaseSerialization.kt | 63 | 序列化 |
| EntityDestroyerIkazuchi.kt | 63 | 具体舰船实体 |
| EntityNorthernHime.kt | 60 | 具体舰船实体 |
| EntityShipBaseEmotions.kt | 52 | 情感系统 |
| ShipContainerMenu.kt | 49 | 舰船容器菜单 |
| EntityDestroyerInazuma.kt | 48 | 具体舰船实体 |
| EntityDestroyerAkatsuki.kt | 47 | 具体舰船实体 |
| EntityBattleshipRe.kt | 43 | 具体舰船实体 |
| EntityDestroyerShimakaze.kt | 40 | 具体舰船实体 |
| EntityDestroyerHibiki.kt | 40 | 具体舰船实体 |
| ShipLegacyPathFinder.kt | 39 | 路径查找 |
| ShipyardRecipes.kt | 25 | 配方系统 |
| ShipInventoryScreen.kt | 25 | 屏幕 |
| RecipePaperScreen.kt | 25 | 屏幕 |
| ModCommands.kt | 25 | 命令系统 |
| EntityMountBrainAi.kt | 25 | 坐骑 AI |
| ... | ... | ... |

## 修复策略

### 核心原则
1. **优先修"被依赖多、依赖别人少"的文件**
2. **使用 code sub agent 并行修复互不冲突的文件组**
3. **每阶段运行 `./gradlew compileKotlin` 验证**

### 阶段划分

#### 阶段 1：底层基础设施（可并行）
- **Group A**: init 注册类（ModItems、ModEntities、ModParticles、ModBlockEntities、ModSounds、ModTabs）
- **Group B**: reference/Values.kt + attachment/AdmiralData.kt + block/entity/IWaypoint.kt
- **Group C**: client/renderer/layer/GenericGlowLayer.kt

#### 阶段 2：核心系统（可并行）
- **Group D**: command/ModCommands.kt
- **Group E**: crafting/ShipyardRecipes.kt
- **Group F**: menu/ModMenus.kt（修复 MenuType 构造参数可空类型问题）

#### 阶段 3：实体基类（串行，因为互相依赖）
- **Step 1**: EntityShipBase.kt（核心基类，4025 行，错误最多）
- **Step 2**: EntityShipBaseCombat.kt、EntityShipBaseEmotions.kt、EntityShipBaseSerialization.kt 等
- **Step 3**: EntityShipBrainAi.kt（拆分为多个 Behavior 文件）

#### 阶段 4：具体实体（可并行）
- 所有 EntityDestroyer*.kt、EntityBattleship*.kt 等子类

#### 阶段 5：菜单和方块实体（可并行）
- ShipContainerMenu.kt、SmallShipyardMenu.kt、LargeShipyardMenu.kt 等
- CraneBlockEntity.kt、SmallShipyardBlockEntity.kt 等

#### 阶段 6：客户端（可并行）
- ClientModEventBusEvents.kt
- client/renderer/*.kt、client/model/*.kt
- client/screen/*.kt

## 常见错误模式

1. **实体属性访问**：`getIsSitting()` → `isInSittingPose`；`isStateMarried()` → `isStateMarried`
2. **舰船属性**：`getLevel()` → `level`；`getFuel()`/`setFuel()` → `fuel`
3. **serverLevel 未解析**：`if (level is ServerLevel)` 分支中显式声明 `val serverLevel = level as ServerLevel`
4. **可空性**：`Array<T?>` 与 `Array<T>`、Optional 可空类型
5. **语法错误**：`set(val)` → `set(value)`
6. **非法 import**：不能从类中静态导入实例方法
7. **匿名内部类中的 this**：`this@OuterClass.property`
8. **Menu/Screen API**：`getXxx()` 改为属性访问；lambda 参数顺序
9. **StreamCodec**：泛型可空类型
10. **Behavior API**：Minecraft 1.21 `Behavior<E>` 接口方法签名变化

## 执行方式

使用 code sub agent 并行执行：
- 每个 agent 负责一个文件组
- agent 之间互不冲突（不修改同一文件）
- 主 agent 汇总结果并验证编译
